
public class Building implements CarbonFootprint{
	//therms of natural gas
	private double buildingEmissions=500; 
	
	public Building() {
		super();
	}
	
	public Building(double buildingEmissions) {
		super();
		this.buildingEmissions = buildingEmissions;
	}

	public double getBuildingEmissions() {
		return buildingEmissions;
	}

	public void setBuildingEmissions(double buildingEmissions) {
		this.buildingEmissions = buildingEmissions;
	}
	
	public double getCarbonFootprint(){
		double carbonfootPrint = 0;
		carbonfootPrint=buildingEmissions*11.7;
		return carbonfootPrint;
		//Pounds CO2 from natural gas
	}

	@Override
	public String toString() {
		return "Building [buildingEmissions=" + buildingEmissions + "]";
	}
	
}
