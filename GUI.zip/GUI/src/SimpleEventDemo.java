import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class SimpleEventDemo extends JFrame{
public SimpleEventDemo() {
JButton jbtOK = new JButton("Click Here to end Program");
setLayout(new FlowLayout());
add(jbtOK);
ActionListener listener = new OKListener();
jbtOK.addActionListener(listener);
}
public class OKListener implements ActionListener{
public void actionPerformed (ActionEvent e) {
System.out.println("Program Ended");
}
}
}