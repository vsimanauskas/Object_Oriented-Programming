
public class Bicycle implements CarbonFootprint{
	private double kmRidden=10.0;
	
	public Bicycle() {
		super();
	}

	public Bicycle(double kmRidden) {
		super();
		this.kmRidden = kmRidden;
	}

	public double getKmRidden() {
		return kmRidden;
	}

	public void setKmRidden(double kmRidden) {
		this.kmRidden = kmRidden;
	}
	
	public double getCarbonFootprint(){
		double carbonfootPrint = 0;
		carbonfootPrint=16*kmRidden;
		//C02 In grams released 
		return carbonfootPrint;
	}

	@Override
	public String toString() {
		return "Bicycle [kmRidden=" + kmRidden + "]";
	}
	
}
