
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
/* My Program creates an interface called carbonfootPrint and then creates three objects that use the interface called building, car and bicycle
 * after that it uses a driver object called driver to create three objects, bicycle, car and building to demonstrate the interface getCarbonFootprint
 * the carbonfootprint interfaces calculates the footprint based on the type of object since they all release co2 differently, the program begins by asking for  a name and displaying it
 * then 
 * the information is displayed to the screen! After the program has ended it asks the user to end the program
 */
public class Driver {

	public static void main(String[] args) {
		ArrayList<CarbonFootprint> arrayList= new ArrayList<>();
		String name=JOptionPane.showInputDialog("Who is using this program? Please Enter a name: ");
		JOptionPane.showMessageDialog(null,"Nice to meet you " + name);
		JFrame fm = new JFrame(); 
		arrayList.add(new Building());
		arrayList.add(new Car());
		arrayList.add(new Bicycle());
		JOptionPane.showMessageDialog(fm,arrayList.get(0)+" Therms of Natural Gas" + "\n" + arrayList.get(0).getCarbonFootprint() + " Pounds of CO2 from natural Gas use");
		JOptionPane.showMessageDialog(fm,arrayList.get(1)+" Efficiency is MPG" + "\n"+arrayList.get(1).getCarbonFootprint() + " CarbonfootPrint is in Kg of CO2");
		JOptionPane.showMessageDialog(fm,arrayList.get(2)+" KM driven by bicycle rider" + "\n" +arrayList.get(2).getCarbonFootprint() + "grams of CO2 released");
		JFrame frame = new SimpleEventDemo();
		frame.setTitle("Program Ender");
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(300, 100);
		frame.setVisible(true);
	
	}

}
