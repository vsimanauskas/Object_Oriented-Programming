
public class Car implements CarbonFootprint{
	//mpg and petrol fuel type
	private double efficiency=20;
	private double milesDriventhatYear=10000;
	
	public Car() {
		super();
	}

	public Car(double efficiency, double milesDriventhatYear) {
		super();
		this.efficiency = efficiency;
		this.milesDriventhatYear = milesDriventhatYear;
	}

	public double getEfficiency() {
		return efficiency;
	}

	public void setEfficiency(double efficiency) {
		this.efficiency = efficiency;
	}

	public double getMilesDriventhatYear() {
		return milesDriventhatYear;
	}

	public void setMilesDriventhatYear(double milesDriventhatYear) {
		this.milesDriventhatYear = milesDriventhatYear;
	}

	public double getCarbonFootprint(){
		double carbonfootPrint = 0;
		carbonfootPrint=milesDriventhatYear/efficiency;
		carbonfootPrint=carbonfootPrint*3.78541;
		carbonfootPrint=carbonfootPrint*2.68;
		// carbonfootPrint is in Kg of CO2
		return carbonfootPrint;
	}

	@Override
	public String toString() {
		return "Car [efficiency=" + efficiency + ", milesDriventhatYear="
				+ milesDriventhatYear + "]";
	}
	
	
}
